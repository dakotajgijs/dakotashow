(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_090c3021._.js",
  "static/chunks/45749_next_dist_compiled_19d9bb24._.js",
  "static/chunks/45749_next_dist_client_9dc14bf5._.js",
  "static/chunks/45749_next_dist_30bf4b43._.js",
  "static/chunks/45749_@swc_helpers_cjs_2b065c8a._.js"
],
    source: "entry"
});
