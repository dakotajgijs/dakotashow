(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/user_app_src_9065b83a._.js",
  "static/chunks/45749_68705c0b._.js"
],
    source: "dynamic"
});
