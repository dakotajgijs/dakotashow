(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/user_app_src_app_globals_db52698e.css",
  "static/chunks/user_app_src_06a6c40f._.js",
  "static/chunks/45749_next_dist_21e5d490._.js"
],
    source: "dynamic"
});
